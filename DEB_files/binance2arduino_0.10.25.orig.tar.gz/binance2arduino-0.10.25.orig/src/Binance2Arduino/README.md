# binance2arduino
v0.10.24

**Binance2Arduino** es una aplicación que busca la cotización de hasta dos criptomonedas mediante la web de Binance y la envía a un *Arduino UNO* para ser desplegada en un display LCD.

El programa busca la cotización de dos criptomonedas (o una si se desea), recibe la información en formato ***json***, la decodifica y la envía como una sola línea al Arduino. 

Más información en: [https://thenerdyapprentice.blogspot.com/](https://thenerdyapprentice.blogspot.com/) 

Saludos!